﻿namespace QuanLyBanHang
{
    partial class frmEditNKCT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtMaPNK = new System.Windows.Forms.TextBox();
            this.cbMaHang = new System.Windows.Forms.ComboBox();
            this.lbMaHang = new System.Windows.Forms.Label();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.lbThanhTien = new System.Windows.Forms.Label();
            this.txtThucNhap = new System.Windows.Forms.TextBox();
            this.lbThucNhap = new System.Windows.Forms.Label();
            this.txtTheoCT = new System.Windows.Forms.TextBox();
            this.lbTheoCT = new System.Windows.Forms.Label();
            this.lbSoPNK = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bnSubmit = new System.Windows.Forms.Button();
            this.bnCancel = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtMaPNK);
            this.panel2.Controls.Add(this.cbMaHang);
            this.panel2.Controls.Add(this.lbMaHang);
            this.panel2.Controls.Add(this.txtThanhTien);
            this.panel2.Controls.Add(this.lbThanhTien);
            this.panel2.Controls.Add(this.txtThucNhap);
            this.panel2.Controls.Add(this.lbThucNhap);
            this.panel2.Controls.Add(this.txtTheoCT);
            this.panel2.Controls.Add(this.lbTheoCT);
            this.panel2.Controls.Add(this.lbSoPNK);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 383);
            this.panel2.TabIndex = 5;
            // 
            // txtMaPNK
            // 
            this.txtMaPNK.Location = new System.Drawing.Point(36, 65);
            this.txtMaPNK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtMaPNK.Name = "txtMaPNK";
            this.txtMaPNK.ReadOnly = true;
            this.txtMaPNK.Size = new System.Drawing.Size(89, 22);
            this.txtMaPNK.TabIndex = 10;
            // 
            // cbMaHang
            // 
            this.cbMaHang.FormattingEnabled = true;
            this.cbMaHang.Location = new System.Drawing.Point(207, 204);
            this.cbMaHang.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cbMaHang.Name = "cbMaHang";
            this.cbMaHang.Size = new System.Drawing.Size(112, 24);
            this.cbMaHang.TabIndex = 9;
            // 
            // lbMaHang
            // 
            this.lbMaHang.AutoSize = true;
            this.lbMaHang.Location = new System.Drawing.Point(207, 166);
            this.lbMaHang.Name = "lbMaHang";
            this.lbMaHang.Size = new System.Drawing.Size(59, 16);
            this.lbMaHang.TabIndex = 8;
            this.lbMaHang.Text = "Mã hàng";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Location = new System.Drawing.Point(36, 204);
            this.txtThanhTien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(89, 22);
            this.txtThanhTien.TabIndex = 7;
            // 
            // lbThanhTien
            // 
            this.lbThanhTien.AutoSize = true;
            this.lbThanhTien.Location = new System.Drawing.Point(33, 166);
            this.lbThanhTien.Name = "lbThanhTien";
            this.lbThanhTien.Size = new System.Drawing.Size(69, 16);
            this.lbThanhTien.TabIndex = 6;
            this.lbThanhTien.Text = "Thành tiền";
            // 
            // txtThucNhap
            // 
            this.txtThucNhap.Location = new System.Drawing.Point(376, 65);
            this.txtThucNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtThucNhap.Name = "txtThucNhap";
            this.txtThucNhap.Size = new System.Drawing.Size(89, 22);
            this.txtThucNhap.TabIndex = 5;
            // 
            // lbThucNhap
            // 
            this.lbThucNhap.AutoSize = true;
            this.lbThucNhap.Location = new System.Drawing.Point(372, 36);
            this.lbThucNhap.Name = "lbThucNhap";
            this.lbThucNhap.Size = new System.Drawing.Size(70, 16);
            this.lbThucNhap.TabIndex = 4;
            this.lbThucNhap.Text = "Thực nhập";
            // 
            // txtTheoCT
            // 
            this.txtTheoCT.Location = new System.Drawing.Point(207, 65);
            this.txtTheoCT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTheoCT.Name = "txtTheoCT";
            this.txtTheoCT.Size = new System.Drawing.Size(89, 22);
            this.txtTheoCT.TabIndex = 3;
            // 
            // lbTheoCT
            // 
            this.lbTheoCT.AutoSize = true;
            this.lbTheoCT.Location = new System.Drawing.Point(204, 36);
            this.lbTheoCT.Name = "lbTheoCT";
            this.lbTheoCT.Size = new System.Drawing.Size(91, 16);
            this.lbTheoCT.TabIndex = 2;
            this.lbTheoCT.Text = "Theo chứng từ";
            // 
            // lbSoPNK
            // 
            this.lbSoPNK.AutoSize = true;
            this.lbSoPNK.Location = new System.Drawing.Point(33, 36);
            this.lbSoPNK.Name = "lbSoPNK";
            this.lbSoPNK.Size = new System.Drawing.Size(118, 16);
            this.lbSoPNK.TabIndex = 0;
            this.lbSoPNK.Text = "Số phiếu nhập kho";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bnSubmit);
            this.panel1.Controls.Add(this.bnCancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 383);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 67);
            this.panel1.TabIndex = 4;
            // 
            // bnSubmit
            // 
            this.bnSubmit.BackColor = System.Drawing.Color.ForestGreen;
            this.bnSubmit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnSubmit.Location = new System.Drawing.Point(207, 31);
            this.bnSubmit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bnSubmit.Name = "bnSubmit";
            this.bnSubmit.Size = new System.Drawing.Size(82, 26);
            this.bnSubmit.TabIndex = 1;
            this.bnSubmit.Text = "Submit";
            this.bnSubmit.UseVisualStyleBackColor = false;
            this.bnSubmit.Click += new System.EventHandler(this.bnSubmit_Click);
            // 
            // bnCancel
            // 
            this.bnCancel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.bnCancel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnCancel.Location = new System.Drawing.Point(36, 31);
            this.bnCancel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bnCancel.Name = "bnCancel";
            this.bnCancel.Size = new System.Drawing.Size(82, 26);
            this.bnCancel.TabIndex = 0;
            this.bnCancel.Text = "Cancel";
            this.bnCancel.UseVisualStyleBackColor = false;
            this.bnCancel.Click += new System.EventHandler(this.bnCancel_Click);
            // 
            // frmEditNKCT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmEditNKCT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmEditPNXCT";
            this.Load += new System.EventHandler(this.frmEditNKCT_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtMaPNK;
        private System.Windows.Forms.ComboBox cbMaHang;
        private System.Windows.Forms.Label lbMaHang;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Label lbThanhTien;
        private System.Windows.Forms.TextBox txtThucNhap;
        private System.Windows.Forms.Label lbThucNhap;
        private System.Windows.Forms.TextBox txtTheoCT;
        private System.Windows.Forms.Label lbTheoCT;
        private System.Windows.Forms.Label lbSoPNK;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bnSubmit;
        private System.Windows.Forms.Button bnCancel;
    }
}
﻿namespace QuanLyBanHang
{
    partial class frmEditXKCT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbMaHang = new System.Windows.Forms.ComboBox();
            this.lbMaHang = new System.Windows.Forms.Label();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.lbThanhTien = new System.Windows.Forms.Label();
            this.txtThucXuat = new System.Windows.Forms.TextBox();
            this.lbThucXuat = new System.Windows.Forms.Label();
            this.txtTheoYC = new System.Windows.Forms.TextBox();
            this.lbTheoYC = new System.Windows.Forms.Label();
            this.cbSoPXK = new System.Windows.Forms.ComboBox();
            this.lbSoPXK = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bnSave = new System.Windows.Forms.Button();
            this.bnCancel = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.cbMaHang);
            this.panel2.Controls.Add(this.lbMaHang);
            this.panel2.Controls.Add(this.txtThanhTien);
            this.panel2.Controls.Add(this.lbThanhTien);
            this.panel2.Controls.Add(this.txtThucXuat);
            this.panel2.Controls.Add(this.lbThucXuat);
            this.panel2.Controls.Add(this.txtTheoYC);
            this.panel2.Controls.Add(this.lbTheoYC);
            this.panel2.Controls.Add(this.cbSoPXK);
            this.panel2.Controls.Add(this.lbSoPXK);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 350);
            this.panel2.TabIndex = 3;
            // 
            // cbMaHang
            // 
            this.cbMaHang.FormattingEnabled = true;
            this.cbMaHang.Location = new System.Drawing.Point(233, 255);
            this.cbMaHang.Name = "cbMaHang";
            this.cbMaHang.Size = new System.Drawing.Size(126, 28);
            this.cbMaHang.TabIndex = 9;
            // 
            // lbMaHang
            // 
            this.lbMaHang.AutoSize = true;
            this.lbMaHang.Location = new System.Drawing.Point(233, 207);
            this.lbMaHang.Name = "lbMaHang";
            this.lbMaHang.Size = new System.Drawing.Size(71, 20);
            this.lbMaHang.TabIndex = 8;
            this.lbMaHang.Text = "Mã hàng";
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.Location = new System.Drawing.Point(41, 255);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(100, 26);
            this.txtThanhTien.TabIndex = 7;
            // 
            // lbThanhTien
            // 
            this.lbThanhTien.AutoSize = true;
            this.lbThanhTien.Location = new System.Drawing.Point(37, 208);
            this.lbThanhTien.Name = "lbThanhTien";
            this.lbThanhTien.Size = new System.Drawing.Size(84, 20);
            this.lbThanhTien.TabIndex = 6;
            this.lbThanhTien.Text = "Thành tiền";
            // 
            // txtThucXuat
            // 
            this.txtThucXuat.Location = new System.Drawing.Point(423, 81);
            this.txtThucXuat.Name = "txtThucXuat";
            this.txtThucXuat.Size = new System.Drawing.Size(100, 26);
            this.txtThucXuat.TabIndex = 5;
            // 
            // lbThucXuat
            // 
            this.lbThucXuat.AutoSize = true;
            this.lbThucXuat.Location = new System.Drawing.Point(419, 45);
            this.lbThucXuat.Name = "lbThucXuat";
            this.lbThucXuat.Size = new System.Drawing.Size(78, 20);
            this.lbThucXuat.TabIndex = 4;
            this.lbThucXuat.Text = "Thực xuất";
            // 
            // txtTheoYC
            // 
            this.txtTheoYC.Location = new System.Drawing.Point(233, 81);
            this.txtTheoYC.Name = "txtTheoYC";
            this.txtTheoYC.Size = new System.Drawing.Size(100, 26);
            this.txtTheoYC.TabIndex = 3;
            // 
            // lbTheoYC
            // 
            this.lbTheoYC.AutoSize = true;
            this.lbTheoYC.Location = new System.Drawing.Point(229, 45);
            this.lbTheoYC.Name = "lbTheoYC";
            this.lbTheoYC.Size = new System.Drawing.Size(104, 20);
            this.lbTheoYC.TabIndex = 2;
            this.lbTheoYC.Text = "Theo yêu cầu";
            // 
            // cbSoPXK
            // 
            this.cbSoPXK.FormattingEnabled = true;
            this.cbSoPXK.Location = new System.Drawing.Point(41, 81);
            this.cbSoPXK.Name = "cbSoPXK";
            this.cbSoPXK.Size = new System.Drawing.Size(126, 28);
            this.cbSoPXK.TabIndex = 1;
            // 
            // lbSoPXK
            // 
            this.lbSoPXK.AutoSize = true;
            this.lbSoPXK.Location = new System.Drawing.Point(37, 45);
            this.lbSoPXK.Name = "lbSoPXK";
            this.lbSoPXK.Size = new System.Drawing.Size(136, 20);
            this.lbSoPXK.TabIndex = 0;
            this.lbSoPXK.Text = "Số phiếu xuất kho";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bnSave);
            this.panel1.Controls.Add(this.bnCancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 350);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 100);
            this.panel1.TabIndex = 2;
            // 
            // bnSave
            // 
            this.bnSave.BackColor = System.Drawing.Color.ForestGreen;
            this.bnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnSave.Location = new System.Drawing.Point(233, 39);
            this.bnSave.Name = "bnSave";
            this.bnSave.Size = new System.Drawing.Size(92, 32);
            this.bnSave.TabIndex = 1;
            this.bnSave.Text = "Save";
            this.bnSave.UseVisualStyleBackColor = false;
            this.bnSave.Click += new System.EventHandler(this.bnSave_Click);
            // 
            // bnCancel
            // 
            this.bnCancel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.bnCancel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bnCancel.Location = new System.Drawing.Point(41, 39);
            this.bnCancel.Name = "bnCancel";
            this.bnCancel.Size = new System.Drawing.Size(92, 32);
            this.bnCancel.TabIndex = 0;
            this.bnCancel.Text = "Cancel";
            this.bnCancel.UseVisualStyleBackColor = false;
            this.bnCancel.Click += new System.EventHandler(this.bnCancel_Click);
            // 
            // frmEditXKCT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frmEditXKCT";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sửa phiếu xuất kho chi tiết";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox cbMaHang;
        private System.Windows.Forms.Label lbMaHang;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.Label lbThanhTien;
        private System.Windows.Forms.TextBox txtThucXuat;
        private System.Windows.Forms.Label lbThucXuat;
        private System.Windows.Forms.TextBox txtTheoYC;
        private System.Windows.Forms.Label lbTheoYC;
        private System.Windows.Forms.ComboBox cbSoPXK;
        private System.Windows.Forms.Label lbSoPXK;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bnSave;
        private System.Windows.Forms.Button bnCancel;
    }
}